def myAbs(x):
    if x < 0:
        x = x-x-x
        print(x)


x = int(input("Please enter a value: "))
myAbs(x)
