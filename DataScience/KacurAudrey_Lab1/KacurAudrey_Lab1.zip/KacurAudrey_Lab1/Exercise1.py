a = 1
b = 2
c = 3
result = a + b + c
print("The result is:", result)
print(f"The result is: {result}")

str1 = "Audrey"
str2 = "Kacur"

print(str1 + " " + str2)
catString = str1 + " " + str2
print(catString)
