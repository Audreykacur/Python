print("Hello World")

print("Hello World")

str1 = "Hello"
str2 = "World"

print(str1, str2)

x = 10
y = 8

result = x + y
print("The result is: ", result)
