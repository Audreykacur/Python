for x in range(0, 3):
    print('Value of x is:', x)

print(x)

while x >= 0:
    #print('Value of x is:', x)
    print(f'Value of x is: {x}')  # f-string
    x -= 1

print(x)
