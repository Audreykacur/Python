
def recordFunction(nm, grade):
    print('Student name: ', nm, '\nStudent grade: ', grade)


name = input('Enter student\'s name: ')
studentGrade = input('Enter student\'s grade:')
recordFunction(name, studentGrade)
