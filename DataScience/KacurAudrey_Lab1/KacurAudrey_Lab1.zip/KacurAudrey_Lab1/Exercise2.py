integer = int(input("Please enter an integer number: "))

if (integer % 2 == 0):
    print(f"{integer} is even")
else:
    print(f"{integer} is odd")
