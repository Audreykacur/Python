a = list(range(5))
a.append(5)  # appends element with value 5 to the end of the list
a.pop()  # removes last element of the list

a.insert(0, 42)  # insert element 42 at index 0
# remove element with index 0 or a.pop() removes last element of the list or use del a[0] to remove element with index 0
a.pop(0)
a.reverse()
a.sort()
