li = list(range(10, 20, 2))
li2 = li[0:]
li3 = li[0:-1]  # stops at the last index
print(li2, "\n", li3)
