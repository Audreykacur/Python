str1 = 'Hello'
str2 = 'world'

str3 = str1 + ' ' + str2
print(str3)
