def addition(x, y):
    print(f"{x} + {y} = {x+y}")


def subtraction(x, y):
    print(f"{x} - {y} = {x-y}")


def multiplication(x, y):
    print(f"{x} * {y} = {x*y}")


def division(x, y):
    print(f"{x} / {y} = {x/y}")
