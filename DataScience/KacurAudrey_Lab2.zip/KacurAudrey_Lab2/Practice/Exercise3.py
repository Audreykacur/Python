def rectangle_area(length, width):
    print(length, width)
    return length * width


result = rectangle_area(width=5, length=10)
print(result)
