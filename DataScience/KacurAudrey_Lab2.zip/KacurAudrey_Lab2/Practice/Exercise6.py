import myLib

print("Program Starts")

myLib.myFunction1()
myLib.myFunction2()
myLib.myFunction3()
print(f"The sum is: {myLib.myFunction4(3, 5)}")

print("Program ends")
