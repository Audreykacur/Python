def rectangle_area(length=2, width=3):
    """Return a rectangle's area"""
    return length * width


print(rectangle_area())

print(rectangle_area(10))

print(rectangle_area(10, 5))
