def square(number):
    """Calculate the square of a number"""
    return number ** 2


print(square(7))
