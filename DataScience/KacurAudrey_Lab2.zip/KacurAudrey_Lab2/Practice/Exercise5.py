def average(*args):
    return sum(args)/len(args)


print(average(5, 10))
print(average(5, 10, 15, 20))
