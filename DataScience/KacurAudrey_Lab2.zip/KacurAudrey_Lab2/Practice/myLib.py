def myFunction1():
    print("Function 1")


def myFunction2():
    print("Function 2")


def myFunction3():
    print("Function 3")


def myFunction4(a, b):
    print("Function 4")
    return (a+b)
