numbers = [3, 7, 1, 4, 2, 8, 5, 6, 2]
print(numbers.index(2))
print(numbers.index(2, 5))
print(numbers.index(2, 1, 6))
